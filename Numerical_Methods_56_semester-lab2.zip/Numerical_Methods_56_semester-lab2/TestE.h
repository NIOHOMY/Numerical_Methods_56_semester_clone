
#ifndef TESTSFUNC_H
#define TESTSFUNC_H

void testOne();
void testTwo();
void testThree();

#endif

